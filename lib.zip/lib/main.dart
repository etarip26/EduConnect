import 'package:flutter/material.dart';

import 'package:test_app/src/app.dart';
import 'package:test_app/src/core/services/service_locator.dart';
import 'package:test_app/src/routing/route_guard.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Restore in-memory role if present
  await authService.hydrateRoleFromStorage();

  final initialRoute = await RouteGuard.decideInitialRoute(storageService);

  runApp(App(initialRoute: initialRoute));
}
