import 'package:flutter/material.dart';

import 'package:test_app/src/ui/auth/login_page.dart';
import 'package:test_app/src/ui/auth/register_page.dart';
import 'package:test_app/src/ui/auth/otp_page.dart';
import 'package:test_app/src/ui/dashboard/dashboard_page.dart';
import 'package:test_app/src/ui/tuition/tuition_list.dart';
import 'package:test_app/src/ui/tuition/tuition_create_page.dart';
import 'package:test_app/src/ui/tuition/tuition_details_page.dart';
import 'package:test_app/src/ui/tuition/my_applications_page.dart';

class AppRouter {
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const LoginPage());

      case '/register':
        return MaterialPageRoute(builder: (_) => const RegisterPage());

      case '/otp':
        final args = settings.arguments as Map<String, dynamic>?;
        final email = args?['email'] as String? ?? '';
        return MaterialPageRoute(builder: (_) => OtpPage(email: email));

      case '/dashboard':
        return MaterialPageRoute(builder: (_) => const DashboardPage());

      case '/tuition':
        return MaterialPageRoute(
          builder: (_) => const TuitionListPage(isTeacherView: false),
        );

      case '/tuition/teacher':
        return MaterialPageRoute(
          builder: (_) => const TuitionListPage(isTeacherView: true),
        );

      case '/tuition/create':
        return MaterialPageRoute(builder: (_) => const TuitionCreatePage());

      case '/tuition/details':
        final post = settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(
          builder: (_) => TuitionDetailsPage(post: post),
        );

      case '/tuition/applications':
        final postId = settings.arguments as String;
        return MaterialPageRoute(
          builder: (_) => MyApplicationsPage(postId: postId),
        );

      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(child: Text('No route defined for ${settings.name}')),
          ),
        );
    }
  }
}
