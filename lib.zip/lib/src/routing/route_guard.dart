import 'package:test_app/src/core/services/storage_service.dart';

class RouteGuard {
  /// Returns '/' or '/dashboard' based on token presence.
  static Future<String> decideInitialRoute(StorageService storage) async {
    final token = await storage.getToken();
    if (token != null && token.isNotEmpty) {
      return '/dashboard';
    }
    return '/';
  }
}
