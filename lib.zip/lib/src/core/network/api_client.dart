import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:test_app/src/config/env.dart';
import 'package:test_app/src/core/services/storage_service.dart';

class ApiClient {
  final String baseUrl;
  final StorageService storage;

  ApiClient({
    this.baseUrl = Env.apiBase,
    required this.storage,
  });

  // ---------------------------------------------
  // COMMON HEADERS
  // ---------------------------------------------
  Future<Map<String, String>> _headers() async {
    final token = await storage.getToken();
    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty)
        'Authorization': 'Bearer $token',
    };
  }

  // ---------------------------------------------
  // GET
  // ---------------------------------------------
  Future<Map<String, dynamic>> get(
    String path, {
    Map<String, String>? query,
  }) async {
    final uri = Uri.parse('$baseUrl$path').replace(
      queryParameters: query,
    );
    final response = await http.get(uri, headers: await _headers());
    return _decode(response);
  }

  // ---------------------------------------------
  // POST
  // ---------------------------------------------
  Future<Map<String, dynamic>> post(
    String path,
    Map<String, dynamic> body,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    final response = await http.post(
      uri,
      headers: await _headers(),
      body: jsonEncode(body),
    );
    return _decode(response);
  }

  // ---------------------------------------------
  // PUT
  // ---------------------------------------------
  Future<Map<String, dynamic>> put(
    String path,
    Map<String, dynamic> body,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    final response = await http.put(
      uri,
      headers: await _headers(),
      body: jsonEncode(body),
    );
    return _decode(response);
  }

  // ---------------------------------------------
  // PATCH
  // ---------------------------------------------
  Future<Map<String, dynamic>> patch(
    String path,
    Map<String, dynamic> body,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    final response = await http.patch(
      uri,
      headers: await _headers(),
      body: jsonEncode(body),
    );
    return _decode(response);
  }

  // ---------------------------------------------
  // RESPONSE DECODER
  // ---------------------------------------------
  Map<String, dynamic> _decode(http.Response response) {
    final body = response.body;
    final data = body.isNotEmpty ? jsonDecode(body) : null;

    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (data is Map<String, dynamic>) return data;
      if (data == null) return {};
      return {'data': data};
    }

    throw ApiException(
      statusCode: response.statusCode,
      message: (data is Map && data['message'] is String)
          ? data['message']
          : 'HTTP ${response.statusCode} error',
    );
  }
}

// ---------------------------------------------
// ERROR CLASS
// ---------------------------------------------
class ApiException implements Exception {
  final int statusCode;
  final String message;

  ApiException({
    required this.statusCode,
    required this.message,
  });

  @override
  String toString() => 'ApiException($statusCode): $message';
}
