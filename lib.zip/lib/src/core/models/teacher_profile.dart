import 'geo_location.dart';

class TeacherProfile {
  final String id;
  final String userId;
  final List<String> subjects;
  final String? bio;
  final GeoLocation? location;
  final double? hourlyRate;

  TeacherProfile({
    required this.id,
    required this.userId,
    required this.subjects,
    this.bio,
    this.location,
    this.hourlyRate,
  });

  factory TeacherProfile.fromJson(Map<String, dynamic> json) {
    return TeacherProfile(
      id: json['_id']?.toString() ?? '',
      userId: json['user']?.toString() ?? '',
      subjects: (json['subjects'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
      bio: json['bio'],
      location: json['location'] != null
          ? GeoLocation.fromJson(json['location'] as Map<String, dynamic>)
          : null,
      hourlyRate: (json['hourlyRate'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'user': userId,
    'subjects': subjects,
    'bio': bio,
    'location': location?.toJson(),
    'hourlyRate': hourlyRate,
  };
}
