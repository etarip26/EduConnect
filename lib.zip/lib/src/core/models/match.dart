class MatchModel {
  const MatchModel({
    required this.id,
    required this.subject,
    required this.studentName,
    required this.teacherName,
  });

  final String id;
  final String subject;
  final String studentName;
  final String teacherName;

  factory MatchModel.fromJson(Map<String, dynamic> json) {
    return MatchModel(
      id: (json['_id'] ?? json['id'] ?? '') as String,
      subject: (json['subject'] ?? '') as String,
      studentName: (json['studentName'] ?? '') as String,
      teacherName: (json['teacherName'] ?? '') as String,
    );
  }
}
