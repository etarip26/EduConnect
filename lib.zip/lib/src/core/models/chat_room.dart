class ChatRoom {
  const ChatRoom({
    required this.id,
    required this.matchId,
    required this.otherName,
    required this.lastMessage,
  });

  final String id;
  final String matchId;
  final String otherName;
  final String lastMessage;

  factory ChatRoom.fromJson(Map<String, dynamic> json) {
    return ChatRoom(
      id: (json['_id'] ?? json['id'] ?? '') as String,
      matchId: (json['matchId'] ?? '') as String,
      otherName: (json['otherName'] ?? json['partnerName'] ?? '') as String,
      lastMessage: (json['lastMessage'] ?? '') as String,
    );
  }
}
