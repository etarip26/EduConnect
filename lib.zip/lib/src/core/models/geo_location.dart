class GeoLocation {
  final String? city;
  final String? area;
  final String? address;

  GeoLocation({this.city, this.area, this.address});

  factory GeoLocation.fromJson(Map<String, dynamic> json) {
    return GeoLocation(
      city: json['city'],
      area: json['area'],
      address: json['address'],
    );
  }

  Map<String, dynamic> toJson() => {
    'city': city,
    'area': area,
    'address': address,
  };
}
