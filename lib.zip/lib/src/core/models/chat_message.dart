class ChatMessage {
  const ChatMessage({
    required this.id,
    required this.roomId,
    required this.senderId,
    required this.text,
  });

  final String id;
  final String roomId;
  final String senderId;
  final String text;

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: (json['_id'] ?? json['id'] ?? '') as String,
      roomId: (json['roomId'] ?? '') as String,
      senderId: (json['senderId'] ?? '') as String,
      text: (json['text'] ?? json['message'] ?? '') as String,
    );
  }
}
