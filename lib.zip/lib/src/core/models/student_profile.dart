import 'geo_location.dart';

class StudentProfile {
  final String id;
  final String userId;
  final String? classLevel;
  final GeoLocation? location;

  StudentProfile({
    required this.id,
    required this.userId,
    this.classLevel,
    this.location,
  });

  factory StudentProfile.fromJson(Map<String, dynamic> json) {
    return StudentProfile(
      id: json['_id']?.toString() ?? '',
      userId: json['user']?.toString() ?? '',
      classLevel: json['classLevel'],
      location: json['location'] != null
          ? GeoLocation.fromJson(json['location'] as Map<String, dynamic>)
          : null,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'user': userId,
    'classLevel': classLevel,
    'location': location?.toJson(),
  };
}
