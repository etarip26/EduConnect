class AppNotification {
  const AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.isRead,
  });

  final String id;
  final String title;
  final String body;
  final bool isRead;

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    return AppNotification(
      id: (json['_id'] ?? json['id'] ?? '') as String,
      title: (json['title'] ?? '') as String,
      body: (json['body'] ?? json['message'] ?? '') as String,
      isRead: (json['isRead'] ?? json['read'] ?? false) as bool,
    );
  }
}
