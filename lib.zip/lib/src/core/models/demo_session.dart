class DemoSession {
  const DemoSession({required this.id, required this.status});

  final String id;
  final String status;

  factory DemoSession.fromJson(Map<String, dynamic> json) {
    return DemoSession(
      id: (json['_id'] ?? json['id'] ?? '') as String,
      status: (json['status'] ?? '') as String,
    );
  }
}
