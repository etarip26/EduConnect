class TuitionPost {
  const TuitionPost({
    required this.id,
    required this.title,
    required this.subject,
    required this.location,
    required this.salary,
    required this.status,
  });

  final String id;
  final String title;
  final String subject;
  final String location;
  final num salary;
  final String status;

  factory TuitionPost.fromJson(Map<String, dynamic> json) {
    return TuitionPost(
      id: (json['_id'] ?? json['id'] ?? '') as String,
      title: (json['title'] ?? '') as String,
      subject: (json['subject'] ?? '') as String,
      location: (json['location'] ?? '') as String,
      salary: (json['salary'] ?? 0) as num,
      status: (json['status'] ?? '') as String,
    );
  }
}
