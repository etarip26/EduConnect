class TuitionApplication {
  final String id;
  final String postId;
  final String teacherId;
  final String? message;
  final String status; // pending / accepted / rejected

  TuitionApplication({
    required this.id,
    required this.postId,
    required this.teacherId,
    required this.status,
    this.message,
  });

  factory TuitionApplication.fromJson(Map<String, dynamic> json) {
    return TuitionApplication(
      id: json['_id']?.toString() ?? '',
      postId: json['post']?.toString() ?? '',
      teacherId: json['teacher']?.toString() ?? '',
      message: json['message'],
      status: json['status'] ?? 'pending',
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'post': postId,
    'teacher': teacherId,
    'message': message,
    'status': status,
  };
}
