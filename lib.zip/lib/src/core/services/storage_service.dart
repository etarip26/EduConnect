import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  StorageService._();

  /// Global singleton
  static final StorageService instance = StorageService._();

  SharedPreferences? _prefs;

  Future<SharedPreferences> get _sp async =>
      _prefs ??= await SharedPreferences.getInstance();

  // ===== TOKEN =====

  Future<void> saveToken(String token) async {
    final sp = await _sp;
    await sp.setString('token', token);
  }

  Future<String?> getToken() async {
    final sp = await _sp;
    return sp.getString('token');
  }

  Future<void> clearTokenAndRole() async {
    final sp = await _sp;
    await sp.remove('token');
    await sp.remove('role');
  }

  // ===== ROLE =====

  Future<void> saveRole(String role) async {
    final sp = await _sp;
    await sp.setString('role', role);
  }

  Future<String?> getRole() async {
    final sp = await _sp;
    return sp.getString('role');
  }
}
