import 'package:test_app/src/config/api_paths.dart';
import 'package:test_app/src/core/network/api_client.dart';

class AdminService {
  final ApiClient apiClient;

  AdminService({required this.apiClient});

  Future<Map<String, dynamic>> getStats() async {
    return apiClient.get(ApiPaths.adminStats);
  }

  Future<Map<String, dynamic>> getUsers() async {
    return apiClient.get(ApiPaths.adminUsers);
  }

  Future<void> suspendUser(String userId, bool suspend) async {
    await apiClient.patch(ApiPaths.adminSuspendUser(userId), {
      'suspended': suspend,
    });
  }

  Future<void> approveTeacher(String teacherId) async {
    await apiClient.patch(ApiPaths.adminApproveTeacher(teacherId), {
      'approved': true,
    });
  }

  Future<void> approveTuition(String tuitionId) async {
    await apiClient.patch(ApiPaths.adminApproveTuition(tuitionId), {
      'approved': true,
    });
  }

  Future<Map<String, dynamic>> getDemos() async {
    return apiClient.get(ApiPaths.adminDemos);
  }

  Future<void> updateDemoStatus(String sessionId, String status) async {
    await apiClient.patch(ApiPaths.adminUpdateDemo(sessionId), {
      'status': status,
    });
  }
}
