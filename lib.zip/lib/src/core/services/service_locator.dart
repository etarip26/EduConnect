import 'package:test_app/src/config/env.dart';
import 'package:test_app/src/core/network/api_client.dart';
import 'package:test_app/src/core/services/storage_service.dart';

import 'package:test_app/src/core/services/auth_service.dart';
import 'package:test_app/src/core/services/profile_service.dart';
import 'package:test_app/src/core/services/tuition_service.dart';
import 'package:test_app/src/core/services/chat_service.dart';
import 'package:test_app/src/core/services/demo_service.dart';
import 'package:test_app/src/core/services/search_service.dart';
import 'package:test_app/src/core/services/matches_service.dart';
import 'package:test_app/src/core/services/review_service.dart';
import 'package:test_app/src/core/services/notification_service.dart';
import 'package:test_app/src/core/services/admin_service.dart';

/// Single global instance of StorageService
final storageService = StorageService.instance;

/// Single global ApiClient
final apiClient = ApiClient(baseUrl: Env.apiBase, storage: storageService);

/// Global services (used in UI)
final authService = AuthService(apiClient: apiClient, storage: storageService);

final profileService = ProfileService(apiClient: apiClient);
final tuitionService = TuitionService(apiClient: apiClient);
final chatService = ChatService(apiClient: apiClient);
final demoService = DemoService(apiClient: apiClient);
final searchService = SearchService(apiClient: apiClient);
final matchesService = MatchesService(apiClient: apiClient);
final reviewService = ReviewService(apiClient: apiClient);
final notificationService = NotificationService(apiClient: apiClient);
final adminService = AdminService(apiClient: apiClient);
