import 'package:test_app/src/config/api_paths.dart';
import 'package:test_app/src/core/network/api_client.dart';

class ProfileService {
  final ApiClient apiClient;

  ProfileService({required this.apiClient});

  Future<Map<String, dynamic>> getMyProfile() async {
    final res = await apiClient.get(ApiPaths.myProfile);
    if (res['profile'] is Map<String, dynamic>) {
      return Map<String, dynamic>.from(res['profile'] as Map);
    }
    return res;
  }
}
