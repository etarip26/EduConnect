import 'package:test_app/src/config/api_paths.dart';
import 'package:test_app/src/core/network/api_client.dart';
import 'package:test_app/src/core/services/storage_service.dart';

class AuthService {
  final ApiClient apiClient;
  final StorageService storage;

  AuthService({required this.apiClient, required this.storage});

  String? _role;
  String? get currentRole => _role;

  Future<void> login(String email, String password) async {
    final res = await apiClient.post(ApiPaths.login, {
      'email': email,
      'password': password,
    });

    final token = res['token'] as String?;
    final role = (res['user'] is Map) ? (res['user']['role'] as String?) : null;

    if (token == null || token.isEmpty) {
      throw Exception('Login failed: no token in response');
    }

    await storage.saveToken(token);

    if (role != null) {
      _role = role;
      await storage.saveRole(role);
    }
  }

  Future<void> register({
    required String name,
    required String email,
    required String password,
    required String role,
  }) async {
    await apiClient.post(ApiPaths.register, {
      'name': name,
      'email': email,
      'password': password,
      'role': role,
    });
  }

  Future<void> requestOtp(String email) async {
    await apiClient.post(ApiPaths.requestOtp, {'email': email});
  }

  Future<void> verifyOtp(String email, String code) async {
    await apiClient.post(ApiPaths.verifyOtp, {'email': email, 'otp': code});
  }

  Future<void> logout() async {
    await storage.clearTokenAndRole();
    _role = null;
  }

  Future<void> hydrateRoleFromStorage() async {
    _role = await storage.getRole();
  }
}
