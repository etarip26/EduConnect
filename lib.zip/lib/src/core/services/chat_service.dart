import 'package:test_app/src/config/api_paths.dart';
import 'package:test_app/src/core/network/api_client.dart';

class ChatService {
  final ApiClient apiClient;

  ChatService({required this.apiClient});

  Future<List<Map<String, dynamic>>> getMyRooms() async {
    final res = await apiClient.get(ApiPaths.myChatRooms);
    final list = res['rooms'] ?? res['data'];
    if (list is List) {
      return List<Map<String, dynamic>>.from(
        list.map((e) => Map<String, dynamic>.from(e as Map)),
      );
    }
    return [];
  }

  Future<Map<String, dynamic>> openOrCreateRoom(String matchId) async {
    return apiClient.post(ApiPaths.chatRooms, {'matchId': matchId});
  }

  Future<List<Map<String, dynamic>>> getMessages(String roomId) async {
    final res = await apiClient.get(ApiPaths.roomMessages(roomId));
    final list = res['messages'] ?? res['data'];
    if (list is List) {
      return List<Map<String, dynamic>>.from(
        list.map((e) => Map<String, dynamic>.from(e as Map)),
      );
    }
    return [];
  }

  Future<void> sendMessage(String roomId, String text) async {
    await apiClient.post(ApiPaths.roomMessages(roomId), {'text': text});
  }
}
