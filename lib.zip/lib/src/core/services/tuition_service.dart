import 'package:test_app/src/config/api_paths.dart';
import 'package:test_app/src/core/network/api_client.dart';

class TuitionService {
  final ApiClient apiClient;

  TuitionService({required this.apiClient});

  Future<List<Map<String, dynamic>>> getAllTuitionPosts() async {
    final res = await apiClient.get(ApiPaths.tuition);
    final list = res['data'] ?? res['tuition'] ?? res['items'];
    if (list is List) {
      return List<Map<String, dynamic>>.from(
        list.map((e) => Map<String, dynamic>.from(e as Map)),
      );
    }
    return [];
  }

  Future<List<Map<String, dynamic>>> getMyTuitionPosts() async {
    final res = await apiClient.get(ApiPaths.tuition, query: {'mine': 'true'});
    final list = res['data'] ?? res['tuition'] ?? res['items'];
    if (list is List) {
      return List<Map<String, dynamic>>.from(
        list.map((e) => Map<String, dynamic>.from(e as Map)),
      );
    }
    return [];
  }

  Future<List<Map<String, dynamic>>> getApplications(String postId) async {
    final res = await apiClient.get(
      ApiPaths.myApplications,
      query: {'postId': postId},
    );
    final list = res['applications'] ?? res['data'];
    if (list is List) {
      return List<Map<String, dynamic>>.from(
        list.map((e) => Map<String, dynamic>.from(e as Map)),
      );
    }
    return [];
  }

  Future<void> createTuitionPost(Map<String, dynamic> payload) async {
    await apiClient.post(ApiPaths.tuition, payload);
  }

  Future<void> applyToPost(String postId) async {
    await apiClient.post(ApiPaths.applyTuition(postId), {});
  }

  Future<void> closePost(String postId) async {
    await apiClient.post(ApiPaths.closeTuition(postId), {});
  }

  Future<List<Map<String, dynamic>>> getMyApplications() async {
    final res = await apiClient.get(ApiPaths.myApplications);
    final list = res['applications'] ?? res['data'];
    if (list is List) {
      return List<Map<String, dynamic>>.from(
        list.map((e) => Map<String, dynamic>.from(e as Map)),
      );
    }
    return [];
  }

  Future<void> acceptApplication(String applicationId) async {
    await apiClient.post(ApiPaths.acceptApplication(applicationId), {});
  }
}
