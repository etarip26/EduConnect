import 'package:test_app/src/config/api_paths.dart';
import 'package:test_app/src/core/network/api_client.dart';

class SearchService {
  final ApiClient apiClient;

  SearchService({required this.apiClient});

  Future<List<Map<String, dynamic>>> searchTeachers(
    Map<String, String> filters,
  ) async {
    final res = await apiClient.get(ApiPaths.searchTeachers, query: filters);
    final list = res['teachers'] ?? res['data'];
    if (list is List) {
      return List<Map<String, dynamic>>.from(
        list.map((e) => Map<String, dynamic>.from(e as Map)),
      );
    }
    return [];
  }

  Future<List<Map<String, dynamic>>> searchStudents(
    Map<String, String> filters,
  ) async {
    final res = await apiClient.get(ApiPaths.searchStudents, query: filters);
    final list = res['posts'] ?? res['data'];
    if (list is List) {
      return List<Map<String, dynamic>>.from(
        list.map((e) => Map<String, dynamic>.from(e as Map)),
      );
    }
    return [];
  }
}
