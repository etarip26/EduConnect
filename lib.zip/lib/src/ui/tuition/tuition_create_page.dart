import 'package:flutter/material.dart';
import '../../core/services/tuition_service.dart';
import '../../core/utils/snackbar_utils.dart';

class TuitionCreatePage extends StatefulWidget {
  const TuitionCreatePage({super.key});

  @override
  State<TuitionCreatePage> createState() => _TuitionCreatePageState();
}

class _TuitionCreatePageState extends State<TuitionCreatePage> {
  final title = TextEditingController();
  final subject = TextEditingController();
  final salary = TextEditingController();
  final location = TextEditingController();
  final description = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Tuition Post')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: title,
            decoration: const InputDecoration(labelText: 'Title'),
          ),
          TextField(
            controller: subject,
            decoration: const InputDecoration(labelText: 'Subject'),
          ),
          TextField(
            controller: salary,
            decoration: const InputDecoration(labelText: 'Salary'),
          ),
          TextField(
            controller: location,
            decoration: const InputDecoration(labelText: 'Location'),
          ),
          TextField(
            controller: description,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'Description'),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => _createPost(context),
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  Future<void> _createPost(BuildContext context) async {
    try {
      await tuitionService.createTuitionPost({
        'title': title.text,
        'subject': subject.text,
        'salary': salary.text,
        'location': location.text,
        'description': description.text,
      });

      showSnackBar(context, 'Post created!');
      Navigator.pop(context);
    } catch (e) {
      showSnackBar(context, e.toString(), isError: true);
    }
  }
}
