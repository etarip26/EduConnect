import 'package:flutter/material.dart';
import '../../core/services/tuition_service.dart';
import '../../core/utils/snackbar_utils.dart';

class MyApplicationsPage extends StatefulWidget {
  final String postId;

  const MyApplicationsPage({super.key, required this.postId});

  @override
  State<MyApplicationsPage> createState() => _MyApplicationsPageState();
}

class _MyApplicationsPageState extends State<MyApplicationsPage> {
  List<dynamic> apps = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadApps();
  }

  Future<void> _loadApps() async {
    try {
      apps = await tuitionService.getApplications(widget.postId);
    } catch (e) {
      showSnackBar(context, e.toString(), isError: true);
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Applications')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : apps.isEmpty
          ? const Center(child: Text('No applications yet'))
          : ListView.builder(
              itemCount: apps.length,
              itemBuilder: (_, i) {
                final a = apps[i];
                return Card(
                  child: ListTile(
                    title: Text(a['teacher']['name']),
                    subtitle: Text(a['teacher']['subject']),
                    trailing: ElevatedButton(
                      onPressed: () async {
                        await tuitionService.acceptApplication(a['_id']);
                        showSnackBar(context, 'Teacher Hired!');
                      },
                      child: const Text('Hire'),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
