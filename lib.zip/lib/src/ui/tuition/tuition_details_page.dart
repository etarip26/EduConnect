import 'package:flutter/material.dart';
import '../../core/services/tuition_service.dart';
import '../../core/utils/snackbar_utils.dart';
import '../../core/services/auth_service.dart';

class TuitionDetailsPage extends StatefulWidget {
  final Map post;

  const TuitionDetailsPage({super.key, required this.post});

  @override
  State<TuitionDetailsPage> createState() => _TuitionDetailsPageState();
}

class _TuitionDetailsPageState extends State<TuitionDetailsPage> {
  bool isStudent = false;
  bool isTeacher = false;

  @override
  void initState() {
    super.initState();
    final role = authService.currentRole;
    isStudent = role == 'student';
    isTeacher = role == 'teacher';
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.post;

    return Scaffold(
      appBar: AppBar(title: Text(p['title'])),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(p['subject'], style: const TextStyle(fontSize: 20)),
          const SizedBox(height: 10),
          Text('Location: ${p['location']}'),
          Text('Salary: ${p['salary']}'),
          const SizedBox(height: 20),

          if (isTeacher) _teacherActions(),
          if (isStudent) _studentActions(),

          const SizedBox(height: 30),
          Text('Description', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(p['description'] ?? 'No description'),
        ],
      ),
    );
  }

  // ------------------ TEACHER ------------------
  Widget _teacherActions() {
    return ElevatedButton.icon(
      onPressed: () async {
        try {
          await tuitionService.applyToPost(widget.post['_id']);
          showSnackBar(context, 'Applied successfully');
        } catch (e) {
          showSnackBar(context, e.toString(), isError: true);
        }
      },
      icon: const Icon(Icons.send),
      label: const Text('Apply to this post'),
    );
  }

  // ------------------ STUDENT ------------------
  Widget _studentActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ElevatedButton.icon(
          onPressed: () async {
            Navigator.pushNamed(
              context,
              '/tuition/applications',
              arguments: widget.post['_id'],
            );
          },
          icon: const Icon(Icons.people),
          label: const Text('View Applications'),
        ),
        const SizedBox(height: 12),
        ElevatedButton.icon(
          onPressed: () async {
            await tuitionService.closePost(widget.post['_id']);
            showSnackBar(context, 'Post closed');
          },
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          icon: const Icon(Icons.close),
          label: const Text('Close Post'),
        ),
      ],
    );
  }
}
