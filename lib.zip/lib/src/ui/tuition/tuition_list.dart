import 'package:flutter/material.dart';
import '../../core/services/tuition_service.dart';
import '../../core/utils/snackbar_utils.dart';

class TuitionListPage extends StatefulWidget {
  final bool isTeacherView; // true = teacher browsing all posts

  const TuitionListPage({super.key, this.isTeacherView = false});

  @override
  State<TuitionListPage> createState() => _TuitionListPageState();
}

class _TuitionListPageState extends State<TuitionListPage> {
  List<dynamic> posts = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadPosts();
  }

  Future<void> _loadPosts() async {
    try {
      if (widget.isTeacherView) {
        posts = await tuitionService.getAllTuitionPosts();
      } else {
        posts = await tuitionService.getMyTuitionPosts();
      }
    } catch (e) {
      showSnackBar(context, e.toString(), isError: true);
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.isTeacherView ? 'Available Tuition Posts' : 'My Tuition Posts',
        ),
      ),
      floatingActionButton: !widget.isTeacherView
          ? FloatingActionButton(
              onPressed: () => Navigator.pushNamed(context, '/tuition/create'),
              child: const Icon(Icons.add),
            )
          : null,
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : posts.isEmpty
          ? const Center(child: Text('No posts yet'))
          : ListView.builder(
              itemCount: posts.length,
              itemBuilder: (_, i) {
                final p = posts[i];
                return Card(
                  child: ListTile(
                    title: Text(p['title']),
                    subtitle: Text('${p['subject']} • ${p['location']}'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        '/tuition/details',
                        arguments: p,
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
