import 'package:flutter/material.dart';
import '../../core/services/auth_service.dart';
import '../../core/services/profile_service.dart';
import '../../core/utils/snackbar_utils.dart';
import 'package:test_app/src/core/services/service_locator.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String? _role;
  String? _name;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final me = await profileService.getMyProfile();
      setState(() {
        _role = me['role'];
        _name = me['name'] ?? 'User';
      });
    } catch (e) {
      showSnackBar(context, e.toString(), isError: true);
    }
  }

  // ---------- Bottom Nav Pages ----------
  List<Widget> get _pages => [
    _homeTab(),
    _chatTab(),
    _tuitionTab(),
    _profileTab(),
  ];

  // ---------- HOME TAB ----------
  Widget _homeTab() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(
          'Hello, ${_name ?? ''} 👋',
          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(
          _role != null ? 'Logged in as $_role' : '',
          style: TextStyle(color: Colors.grey.shade700),
        ),
        const SizedBox(height: 28),

        // ---------- Role Based Sections ----------
        if (_role == 'student') ..._studentHomeCards(),
        if (_role == 'teacher') ..._teacherHomeCards(),
        if (_role == 'admin') ..._adminHomeCards(),
      ],
    );
  }

  // ---------- CHAT TAB ----------
  Widget _chatTab() {
    return Center(
      child: Text(
        'Chat UI Coming Soon',
        style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
      ),
    );
  }

  // ---------- TUITION TAB ----------
  Widget _tuitionTab() {
    return Center(
      child: Text(
        'Tuition Features Coming Soon',
        style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
      ),
    );
  }

  // ---------- PROFILE TAB ----------
  Widget _profileTab() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SizedBox(height: 10),
        const Text(
          'My Profile',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),

        ListTile(
          leading: const CircleAvatar(radius: 24, child: Icon(Icons.person)),
          title: Text(_name ?? ''),
          subtitle: Text('Role: ${_role ?? ''}'),
        ),

        const SizedBox(height: 24),

        ElevatedButton.icon(
          onPressed: () {
            authService.logout();
            Navigator.of(
              context,
            ).pushNamedAndRemoveUntil('/', (route) => false);
          },
          icon: const Icon(Icons.logout),
          label: const Text('Logout'),
        ),
      ],
    );
  }

  // ================================
  // STUDENT HOME CARDS
  // ================================
  List<Widget> _studentHomeCards() {
    return [
      _dashboardCard(
        title: 'Search Teachers',
        icon: Icons.search,
        onTap: () {
          showSnackBar(context, 'Search UI not implemented yet');
        },
      ),
      _dashboardCard(
        title: 'My Tuition Posts',
        icon: Icons.book_outlined,
        onTap: () {
          showSnackBar(context, 'Tuition Posts UI not implemented yet');
        },
      ),
      _dashboardCard(
        title: 'My Applications',
        icon: Icons.assignment,
        onTap: () {
          showSnackBar(context, 'Applications UI not implemented yet');
        },
      ),
      _dashboardCard(
        title: 'My Matches',
        icon: Icons.favorite,
        onTap: () {
          showSnackBar(context, 'Matches UI not implemented yet');
        },
      ),
    ];
  }

  // ================================
  // TEACHER HOME CARDS
  // ================================
  List<Widget> _teacherHomeCards() {
    return [
      _dashboardCard(
        title: 'Find Tuition Posts',
        icon: Icons.search,
        onTap: () {
          showSnackBar(context, 'Search Tuition UI not implemented yet');
        },
      ),
      _dashboardCard(
        title: 'My Demo Sessions',
        icon: Icons.video_camera_front,
        onTap: () {
          showSnackBar(context, 'Demo UI not implemented yet');
        },
      ),
      _dashboardCard(
        title: 'My Reviews',
        icon: Icons.star,
        onTap: () {
          showSnackBar(context, 'Reviews UI not implemented yet');
        },
      ),
    ];
  }

  // ================================
  // ADMIN HOME CARDS
  // ================================
  List<Widget> _adminHomeCards() {
    return [
      _dashboardCard(
        title: 'System Stats',
        icon: Icons.analytics,
        onTap: () {
          showSnackBar(context, 'Admin Stats UI coming soon');
        },
      ),
      _dashboardCard(
        title: 'User Management',
        icon: Icons.people,
        onTap: () {
          showSnackBar(context, 'Admin User UI coming soon');
        },
      ),
      _dashboardCard(
        title: 'Verify Teachers',
        icon: Icons.verified,
        onTap: () {
          showSnackBar(context, 'Admin Verify UI coming soon');
        },
      ),
    ];
  }

  // ================================
  // CARD WIDGET
  // ================================
  Widget _dashboardCard({
    required String title,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(
          vertical: 16,
          horizontal: 20,
        ),
        leading: CircleAvatar(
          radius: 24,
          backgroundColor: Colors.indigo.withOpacity(0.1),
          child: Icon(icon, size: 26, color: Colors.indigo),
        ),
        title: Text(title, style: const TextStyle(fontSize: 18)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 18),
        onTap: onTap,
      ),
    );
  }

  // ================================
  // MAIN BUILD
  // ================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.chat_bubble), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.book), label: 'Tuition'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
