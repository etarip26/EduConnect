class ApiPaths {
  // ========= AUTH =========
  static const String register = '/auth/register';
  static const String login = '/auth/login';
  static const String me = '/auth/me';
  static const String requestOtp = '/auth/request-otp';
  static const String verifyOtp = '/auth/verify-otp';

  // ========= PROFILE =========
  static const String myProfile = '/profile/me';
  static const String studentProfile = '/profile/student';
  static const String teacherProfile = '/profile/teacher';

  // ========= TUITION =========
  static const String tuition = '/tuition'; // GET list, POST create

  static String closeTuition(String postId) => '/tuition/close/$postId';
  static String applyTuition(String postId) => '/tuition/apply/$postId';
  static const String myApplications = '/tuition/applications/my';

  // This one you said is to be added on backend – we still define path:
  static String acceptApplication(String applicationId) =>
      '/tuition/accept/$applicationId';

  // ========= SEARCH =========
  static const String searchTeachers = '/search/teachers';
  static const String searchStudents = '/search/students';

  // ========= MATCHES =========
  static const String myMatches = '/matches/my';

  // ========= CHAT =========
  static const String chatRooms = '/chat/rooms';
  static const String myChatRooms = '/chat/rooms/my';

  static String roomMessages(String roomId) => '/chat/rooms/$roomId/messages';

  // ========= DEMOS =========
  static const String demoRequest = '/demos/request';
  static const String myDemos = '/demos/my';

  // ========= REVIEWS =========
  static String teacherReviews(String teacherId) =>
      '/reviews/teacher/$teacherId';

  // ========= NOTIFICATIONS =========
  static const String myNotifications = '/notifications/my';
  static const String adminNotification = '/notifications/admin';

  // ========= ADMIN =========
  static const String adminStats = '/admin/stats';
  static const String adminUsers = '/admin/users';
  static const String adminDemos = '/admin/demos';

  static String adminSuspendUser(String userId) =>
      '/admin/users/$userId/suspend';

  static String adminApproveTeacher(String teacherId) =>
      '/admin/teachers/$teacherId/approve';

  static String adminApproveTuition(String tuitionId) =>
      '/admin/tuition/$tuitionId/approve';

  static String adminUpdateDemo(String sessionId) => '/admin/demos/$sessionId';
}
